# lcquad2_smart_task
evaluation of answer types of lcquad2 dataset

Input file: data_files/lcquad2_gold_standard.json \
Dummy Predictions File: lcquad2_dummy_predictions    \
Evaluated Predictions File with Rank and RR: lcquad2_dummy_predictions_with_rr.json \

Full testing input file: lcquad2_full_predictions.json   \
Full testing output file with rank and rr: lcquad2_full_predictions_with_rr.json   \
<br>
final_scores_dummy_date_time.json has the following as its content for a dummy testing: \
    "category_matched_accuracy": 0.71,
    "type_mrr": 0.36
